<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/pt-br:Editando_wp-config.php
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define( 'DB_NAME', '' );


/** Usuário do banco de dados MySQL */
define( 'DB_USER', '' );


/** Senha do banco de dados MySQL */
define( 'DB_PASSWORD', '' );


/** Nome do host do MySQL */
define( 'DB_HOST', '' );


/** Charset do banco de dados a ser usado na criação das tabelas. */
define( 'DB_CHARSET', 'utf8mb4' );


/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '(VnOD`HX+&iZYJ]4Ro50jgP*nGDxVa.aXeb_<)>Jr.5Dv{>,Og QjsdJ<PA.6e?e' );

define( 'SECURE_AUTH_KEY',  'G[H3n6Z^ldSbQ+T#Yskuy[h fj$}-UzGt Xe%mZ9-49B88xr0B7,ap`i,[=@8bLg' );

define( 'LOGGED_IN_KEY',    '%xs<OiI18H]A!-^X#*+>-#uK81Q7TKwI/6>,AN2j!pa|M(3$(g*h/:gO(1;HDq{z' );

define( 'NONCE_KEY',        'JB)mKCTtBemOQI =[bHCQ#h$_ksMb~5@KA8.Qw5i|5#<U>~ r^(tU89*Vj+/w*oz' );

define( 'AUTH_SALT',        'U39k.4y{~3#9*|Rj/ji:E`@CabW$7BGGiXu/El)Tdez{J&<r%L$Evzs&yihPJ0y_' );

define( 'SECURE_AUTH_SALT', 'Y&28pKj*t68RMHftz]&P{aeA{^R[c;hYayy!>S^Os)=?n&YOMIw?VBm2|6*w:xx_' );

define( 'LOGGED_IN_SALT',   'bY#SL79/,QOSW. VRGZ3Eq4s{%CbzvJWn%>+KL! IF|84}wcppcl(ei$B.EFgNAQ' );

define( 'NONCE_SALT',       '?U(G?Nt;T4O@3Hrtnt5rBxQR,wE|jh/f8N)it+sMOh06s?!#+:vDEvUcFH)2n#4S' );


/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix = 'lp_';


/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://codex.wordpress.org/pt-br:Depura%C3%A7%C3%A3o_no_WordPress
 */
define('WP_DEBUG', false);

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Configura as variáveis e arquivos do WordPress. */
require_once(ABSPATH . 'wp-settings.php');
